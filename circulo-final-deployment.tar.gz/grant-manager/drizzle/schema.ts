import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, decimal } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  preferredLanguage: mysqlEnum("preferred_language", ["en", "es", "ca", "eu"]).default("en").notNull(), // en=English, es=Spanish, ca=Catalan, eu=Basque
  googleId: varchar("google_id", { length: 255 }), // Google OAuth ID
  googleAccessToken: text("google_access_token"), // Encrypted Google access token
  googleRefreshToken: text("google_refresh_token"), // Encrypted Google refresh token
  googleTokenExpiry: timestamp("google_token_expiry"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Grant opportunities from various funding sources
 * Covers Process 1: Grant Opportunity Identification and Screening
 */
export const grantOpportunities = mysqlTable("grant_opportunities", {
  id: int("id").autoincrement().primaryKey(),
  fundingSource: varchar("funding_source", { length: 255 }).notNull(), // Ministry, EU, etc.
  programTitle: varchar("program_title", { length: 500 }).notNull(),
  publicationDate: timestamp("publication_date"),
  applicationStartDate: timestamp("application_start_date"),
  applicationDeadline: timestamp("application_deadline").notNull(),
  minAmount: int("min_amount"), // in euros
  maxAmount: int("max_amount"), // in euros
  coFinancingPercentage: int("co_financing_percentage"), // 0-100
  eligibilityCriteria: text("eligibility_criteria"),
  thematicArea: varchar("thematic_area", { length: 255 }),
  geographicScope: varchar("geographic_scope", { length: 255 }),
  strategicFitScore: int("strategic_fit_score"), // 1-5
  priorityScore: int("priority_score"), // calculated weighted score (stored as int, divide by 10 for decimal)
  status: mysqlEnum("status", ["monitoring", "preparing", "submitted", "awarded", "rejected", "archived"]).default("monitoring").notNull(),
  assignedToUserId: int("assigned_to_user_id"),
  callDocumentationUrl: text("call_documentation_url"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type GrantOpportunity = typeof grantOpportunities.$inferSelect;
export type InsertGrantOpportunity = typeof grantOpportunities.$inferInsert;

/**
 * Grant applications submitted by the organization
 * Covers Process 2-6: From eligibility assessment through submission
 */
export const applications = mysqlTable("applications", {
  id: int("id").autoincrement().primaryKey(),
  grantOpportunityId: int("grant_opportunity_id").notNull(),
  projectTitle: varchar("project_title", { length: 500 }).notNull(),
  status: mysqlEnum("status", ["draft", "in_review", "submitted", "awarded", "rejected", "withdrawn"]).default("draft").notNull(),
  submissionDate: timestamp("submission_date"),
  requestedAmount: int("requested_amount"), // in euros
  coFinancingAmount: int("co_financing_amount"), // in euros
  projectStartDate: timestamp("project_start_date"),
  projectEndDate: timestamp("project_end_date"),
  projectDuration: int("project_duration"), // in months
  targetBeneficiaries: text("target_beneficiaries"),
  geographicScope: varchar("geographic_scope", { length: 255 }),
  eligibilityCheckCompleted: boolean("eligibility_check_completed").default(false),
  eligibilityNotes: text("eligibility_notes"),
  assignedToUserId: int("assigned_to_user_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type Application = typeof applications.$inferSelect;
export type InsertApplication = typeof applications.$inferInsert;

/**
 * Project design and narrative for each application
 * Covers Process 4: Project Design and Narrative Development
 */
export const projects = mysqlTable("projects", {
  id: int("id").autoincrement().primaryKey(),
  applicationId: int("application_id").notNull().unique(),
  problemStatement: text("problem_statement"),
  objectives: text("objectives"), // JSON array of objectives
  activities: text("activities"), // JSON array of activities
  expectedResults: text("expected_results"),
  indicators: text("indicators"), // JSON array of indicators
  methodology: text("methodology"),
  innovationAspects: text("innovation_aspects"),
  sustainabilityPlan: text("sustainability_plan"),
  riskAssessment: text("risk_assessment"),
  timeline: text("timeline"), // JSON array of milestones
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type Project = typeof projects.$inferSelect;
export type InsertProject = typeof projects.$inferInsert;

/**
 * Budget items for each application
 * Covers Process 5: Budget Development and Justification
 */
export const budgetItems = mysqlTable("budget_items", {
  id: int("id").autoincrement().primaryKey(),
  applicationId: int("application_id").notNull(),
  category: varchar("category", { length: 255 }).notNull(), // Personnel, Equipment, Travel, etc.
  description: text("description").notNull(),
  quantity: int("quantity"),
  unitCost: int("unit_cost"), // in cents to avoid decimal issues
  totalCost: int("total_cost"), // in cents
  fundingSource: mysqlEnum("funding_source", ["grant", "co_financing", "in_kind"]).notNull(),
  justification: text("justification"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type BudgetItem = typeof budgetItems.$inferSelect;
export type InsertBudgetItem = typeof budgetItems.$inferInsert;

/**
 * Partners involved in grant applications
 */
export const partners = mysqlTable("partners", {
  id: int("id").autoincrement().primaryKey(),
  applicationId: int("application_id").notNull(),
  organizationName: varchar("organization_name", { length: 500 }).notNull(),
  contactPerson: varchar("contact_person", { length: 255 }),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 50 }),
  role: varchar("role", { length: 255 }), // Lead, Partner, Subcontractor
  country: varchar("country", { length: 100 }),
  contribution: text("contribution"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type Partner = typeof partners.$inferSelect;
export type InsertPartner = typeof partners.$inferInsert;

/**
 * Documents related to applications and organization
 * Covers Process 3: Entity Documentation Preparation
 */
export const documents = mysqlTable("documents", {
  id: int("id").autoincrement().primaryKey(),
  applicationId: int("application_id"), // null for organization-level documents
  documentType: varchar("document_type", { length: 255 }).notNull(), // Statutes, Tax Certificate, etc.
  documentName: varchar("document_name", { length: 500 }).notNull(),
  fileUrl: text("file_url").notNull(),
  fileKey: varchar("file_key", { length: 500 }).notNull(),
  mimeType: varchar("mime_type", { length: 100 }),
  fileSize: int("file_size"), // in bytes
  expirationDate: timestamp("expiration_date"),
  uploadedByUserId: int("uploaded_by_user_id"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type Document = typeof documents.$inferSelect;
export type InsertDocument = typeof documents.$inferInsert;

/**
 * Activities executed as part of awarded grants
 * Covers Process 8: Project Execution and Documentation
 */
export const activities = mysqlTable("activities", {
  id: int("id").autoincrement().primaryKey(),
  applicationId: int("application_id").notNull(),
  activityName: varchar("activity_name", { length: 500 }).notNull(),
  description: text("description"),
  plannedStartDate: timestamp("planned_start_date"),
  plannedEndDate: timestamp("planned_end_date"),
  actualStartDate: timestamp("actual_start_date"),
  actualEndDate: timestamp("actual_end_date"),
  status: mysqlEnum("status", ["planned", "in_progress", "completed", "cancelled"]).default("planned").notNull(),
  participantCount: int("participant_count"),
  location: varchar("location", { length: 255 }),
  responsibleUserId: int("responsible_user_id"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type Activity = typeof activities.$inferSelect;
export type InsertActivity = typeof activities.$inferInsert;

/**
 * Expenses incurred during grant execution
 * Covers Process 9: Financial Management and Compliance
 */
export const expenses = mysqlTable("expenses", {
  id: int("id").autoincrement().primaryKey(),
  applicationId: int("application_id").notNull(),
  budgetItemId: int("budget_item_id"), // link to budget item if applicable
  expenseDate: timestamp("expense_date").notNull(),
  description: text("description").notNull(),
  category: varchar("category", { length: 255 }).notNull(),
  amount: int("amount").notNull(), // in cents
  vendor: varchar("vendor", { length: 500 }),
  invoiceNumber: varchar("invoice_number", { length: 255 }),
  paymentMethod: varchar("payment_method", { length: 100 }),
  paymentDate: timestamp("payment_date"),
  receiptUrl: text("receipt_url"),
  receiptFileKey: varchar("receipt_file_key", { length: 500 }),
  isEligible: boolean("is_eligible").default(true),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type Expense = typeof expenses.$inferSelect;
export type InsertExpense = typeof expenses.$inferInsert;

/**
 * Reports submitted to funders
 * Covers Process 10: Monitoring, Evaluation, and Reporting
 */
export const reports = mysqlTable("reports", {
  id: int("id").autoincrement().primaryKey(),
  applicationId: int("application_id").notNull(),
  reportType: mysqlEnum("report_type", ["interim", "final", "financial", "technical"]).notNull(),
  reportingPeriodStart: timestamp("reporting_period_start"),
  reportingPeriodEnd: timestamp("reporting_period_end"),
  dueDate: timestamp("due_date"),
  submissionDate: timestamp("submission_date"),
  status: mysqlEnum("status", ["draft", "submitted", "approved", "revision_requested"]).default("draft").notNull(),
  content: text("content"),
  documentUrl: text("document_url"),
  documentFileKey: varchar("document_file_key", { length: 500 }),
  submittedByUserId: int("submitted_by_user_id"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type Report = typeof reports.$inferSelect;
export type InsertReport = typeof reports.$inferInsert;

/**
 * Audit trail and justification documentation
 * Covers Process 11: Final Justification and Audit
 */
export const auditRecords = mysqlTable("audit_records", {
  id: int("id").autoincrement().primaryKey(),
  applicationId: int("application_id").notNull(),
  auditDate: timestamp("audit_date"),
  auditType: varchar("audit_type", { length: 255 }),
  auditor: varchar("auditor", { length: 500 }),
  findings: text("findings"),
  recommendations: text("recommendations"),
  status: mysqlEnum("status", ["scheduled", "in_progress", "completed", "passed", "failed"]).default("scheduled").notNull(),
  documentUrl: text("document_url"),
  documentFileKey: varchar("document_file_key", { length: 500 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type AuditRecord = typeof auditRecords.$inferSelect;
export type InsertAuditRecord = typeof auditRecords.$inferInsert;

/**
 * Notifications and reminders for deadlines
 */
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  title: varchar("title", { length: 500 }).notNull(),
  message: text("message"),
  type: mysqlEnum("type", ["deadline", "status_change", "document_expiry", "general"]).notNull(),
  relatedEntityType: varchar("related_entity_type", { length: 100 }), // grant_opportunity, application, etc.
  relatedEntityId: int("related_entity_id"),
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

/**
 * API credentials for external integrations
 * Stores encrypted credentials for various external services
 */
export const apiCredentials = mysqlTable("api_credentials", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  serviceName: varchar("service_name", { length: 255 }).notNull(), // Google Drive, etc.
  credentialType: varchar("credential_type", { length: 100 }).notNull(), // oauth, api_key, etc.
  encryptedCredentials: text("encrypted_credentials").notNull(), // JSON encrypted with app secret
  isActive: boolean("is_active").default(true),
  expiresAt: timestamp("expires_at"),
  lastUsedAt: timestamp("last_used_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type ApiCredential = typeof apiCredentials.$inferSelect;
export type InsertApiCredential = typeof apiCredentials.$inferInsert;

/**
 * Audit log for security and compliance
 * Tracks all sensitive operations
 */
export const auditLogs = mysqlTable("audit_logs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id"),
  action: varchar("action", { length: 255 }).notNull(), // login, document_upload, data_export, etc.
  entityType: varchar("entity_type", { length: 100 }), // application, document, etc.
  entityId: int("entity_id"),
  ipAddress: varchar("ip_address", { length: 45 }),
  userAgent: text("user_agent"),
  metadata: text("metadata"), // JSON with additional context
  status: mysqlEnum("status", ["success", "failure", "error"]).notNull(),
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = typeof auditLogs.$inferInsert;

/**
 * Translations for multi-language support
 * Stores translations for dynamic content
 */
export const translations = mysqlTable("translations", {
  id: int("id").autoincrement().primaryKey(),
  entityType: varchar("entity_type", { length: 100 }).notNull(), // grant_opportunity, application, etc.
  entityId: int("entity_id").notNull(),
  fieldName: varchar("field_name", { length: 100 }).notNull(), // title, description, etc.
  language: mysqlEnum("language", ["en", "es", "ca", "eu"]).notNull(),
  translatedText: text("translated_text").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type Translation = typeof translations.$inferSelect;
export type InsertTranslation = typeof translations.$inferInsert;

/**
 * Google Drive file references
 * Tracks documents imported from Google Drive
 */
export const googleDriveFiles = mysqlTable("google_drive_files", {
  id: int("id").autoincrement().primaryKey(),
  documentId: int("document_id").notNull(), // references documents table
  googleFileId: varchar("google_file_id", { length: 255 }).notNull(),
  googleFileName: varchar("google_file_name", { length: 500 }),
  googleMimeType: varchar("google_mime_type", { length: 100 }),
  googleWebViewLink: text("google_web_view_link"),
  syncEnabled: boolean("sync_enabled").default(false),
  lastSyncedAt: timestamp("last_synced_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type GoogleDriveFile = typeof googleDriveFiles.$inferSelect;
export type InsertGoogleDriveFile = typeof googleDriveFiles.$inferInsert;

/**
 * WhatsApp messages received via N8N
 * Stores messages and voice note transcriptions from WhatsApp
 */
export const whatsappMessages = mysqlTable("whatsapp_messages", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id"), // linked user if identified
  phoneNumber: varchar("phone_number", { length: 50 }).notNull(),
  senderName: varchar("sender_name", { length: 255 }),
  messageType: mysqlEnum("message_type", ["text", "voice", "image", "document", "video"]).notNull(),
  messageContent: text("message_content"), // text content or transcription
  originalAudioUrl: text("original_audio_url"), // for voice messages
  transcriptionStatus: mysqlEnum("transcription_status", ["pending", "processing", "completed", "failed"]),
  mediaUrl: text("media_url"), // for images, documents, videos
  mediaFileKey: varchar("media_file_key", { length: 500 }),
  applicationId: int("application_id"), // if linked to specific application
  isProcessed: boolean("is_processed").default(false),
  processedAt: timestamp("processed_at"),
  metadata: text("metadata"), // JSON with additional N8N data
  receivedAt: timestamp("received_at").defaultNow().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type WhatsappMessage = typeof whatsappMessages.$inferSelect;
export type InsertWhatsappMessage = typeof whatsappMessages.$inferInsert;

/**
 * Email notifications sent to users
 * Tracks all email communications
 */
export const emailLogs = mysqlTable("email_logs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  recipientEmail: varchar("recipient_email", { length: 320 }).notNull(),
  subject: varchar("subject", { length: 500 }).notNull(),
  emailType: varchar("email_type", { length: 100 }).notNull(), // deadline_reminder, status_update, etc.
  templateName: varchar("template_name", { length: 255 }),
  content: text("content"),
  relatedEntityType: varchar("related_entity_type", { length: 100 }),
  relatedEntityId: int("related_entity_id"),
  status: mysqlEnum("status", ["pending", "sent", "failed", "bounced"]).default("pending").notNull(),
  sentAt: timestamp("sent_at"),
  errorMessage: text("error_message"),
  metadata: text("metadata"), // JSON with additional data
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type EmailLog = typeof emailLogs.$inferSelect;
export type InsertEmailLog = typeof emailLogs.$inferInsert;

/**
 * AI-powered document assistance sessions
 * Tracks AI interactions for document improvement
 */
export const aiAssistanceSessions = mysqlTable("ai_assistance_sessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  sessionType: mysqlEnum("session_type", ["review", "translation", "generation", "correction", "chat"]).notNull(),
  applicationId: int("application_id"),
  documentId: int("document_id"),
  inputText: text("input_text"),
  outputText: text("output_text"),
  sourceLanguage: mysqlEnum("source_language", ["en", "es", "ca", "eu"]),
  targetLanguage: mysqlEnum("target_language", ["en", "es", "ca", "eu"]),
  suggestions: text("suggestions"), // JSON array of AI suggestions
  tokensUsed: int("tokens_used"),
  model: varchar("model", { length: 100 }),
  status: mysqlEnum("status", ["processing", "completed", "failed"]).default("processing").notNull(),
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
});

export type AiAssistanceSession = typeof aiAssistanceSessions.$inferSelect;
export type InsertAiAssistanceSession = typeof aiAssistanceSessions.$inferInsert;

/**
 * N8N webhook configurations
 * Stores webhook endpoints and authentication
 */
export const n8nWebhooks = mysqlTable("n8n_webhooks", {
  id: int("id").autoincrement().primaryKey(),
  webhookName: varchar("webhook_name", { length: 255 }).notNull(),
  webhookUrl: text("webhook_url").notNull(),
  webhookType: varchar("webhook_type", { length: 100 }).notNull(), // whatsapp, email, etc.
  authToken: varchar("auth_token", { length: 500 }), // encrypted token
  isActive: boolean("is_active").default(true),
  lastTriggeredAt: timestamp("last_triggered_at"),
  triggerCount: int("trigger_count").default(0),
  metadata: text("metadata"), // JSON configuration
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type N8nWebhook = typeof n8nWebhooks.$inferSelect;
export type InsertN8nWebhook = typeof n8nWebhooks.$inferInsert;

/**
 * NGO Organization Profile
 * Stores organizational information used across applications and reports
 */
export const organizationProfile = mysqlTable("organization_profile", {
  id: int("id").autoincrement().primaryKey(),
  organizationName: varchar("organization_name", { length: 500 }).notNull(),
  legalName: varchar("legal_name", { length: 500 }),
  taxId: varchar("tax_id", { length: 100 }),
  registrationNumber: varchar("registration_number", { length: 100 }),
  foundedYear: int("founded_year"),
  organizationType: varchar("organization_type", { length: 100 }), // NGO, Foundation, Association
  missionStatement: text("mission_statement"),
  visionStatement: text("vision_statement"),
  thematicAreas: text("thematic_areas"), // JSON array
  geographicScope: text("geographic_scope"), // JSON array
  targetBeneficiaries: text("target_beneficiaries"),
  address: text("address"),
  city: varchar("city", { length: 255 }),
  state: varchar("state", { length: 255 }),
  country: varchar("country", { length: 100 }),
  postalCode: varchar("postal_code", { length: 20 }),
  phone: varchar("phone", { length: 50 }),
  email: varchar("email", { length: 320 }),
  website: varchar("website", { length: 500 }),
  socialMedia: text("social_media"), // JSON object
  logoUrl: text("logo_url"),
  logoFileKey: varchar("logo_file_key", { length: 500 }),
  staffCount: int("staff_count"),
  volunteerCount: int("volunteer_count"),
  annualBudget: int("annual_budget"), // in cents
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type OrganizationProfile = typeof organizationProfile.$inferSelect;
export type InsertOrganizationProfile = typeof organizationProfile.$inferInsert;

/**
 * Impact Metrics
 * Tracks quantifiable impact data for reports
 */
export const impactMetrics = mysqlTable("impact_metrics", {
  id: int("id").autoincrement().primaryKey(),
  applicationId: int("application_id"), // null for organization-wide metrics
  metricName: varchar("metric_name", { length: 255 }).notNull(),
  metricCategory: varchar("metric_category", { length: 100 }), // beneficiaries, activities, outcomes
  metricValue: int("metric_value").notNull(),
  metricUnit: varchar("metric_unit", { length: 100 }), // people, hours, events, etc.
  description: text("description"),
  reportingPeriodStart: timestamp("reporting_period_start"),
  reportingPeriodEnd: timestamp("reporting_period_end"),
  dataSource: varchar("data_source", { length: 255 }),
  verificationStatus: mysqlEnum("verification_status", ["unverified", "verified", "audited"]).default("unverified"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type ImpactMetric = typeof impactMetrics.$inferSelect;
export type InsertImpactMetric = typeof impactMetrics.$inferInsert;

/**
 * Impact Reports
 * Generated reports for donors and stakeholders
 */
export const impactReports = mysqlTable("impact_reports", {
  id: int("id").autoincrement().primaryKey(),
  reportTitle: varchar("report_title", { length: 500 }).notNull(),
  reportType: mysqlEnum("report_type", ["annual", "quarterly", "project", "donor", "custom"]).notNull(),
  applicationId: int("application_id"), // null for organization-wide reports
  reportingPeriodStart: timestamp("reporting_period_start").notNull(),
  reportingPeriodEnd: timestamp("reporting_period_end").notNull(),
  status: mysqlEnum("status", ["draft", "review", "finalized", "sent"]).default("draft").notNull(),
  content: text("content"), // Rich text/HTML content
  generatedByAi: boolean("generated_by_ai").default(false),
  aiPrompt: text("ai_prompt"), // Prompt used for AI generation
  includedMetrics: text("included_metrics"), // JSON array of metric IDs
  targetAudience: varchar("target_audience", { length: 255 }), // donors, board, public
  language: mysqlEnum("language", ["en", "es", "ca", "eu"]).default("en").notNull(),
  pdfUrl: text("pdf_url"),
  pdfFileKey: varchar("pdf_file_key", { length: 500 }),
  createdByUserId: int("created_by_user_id").notNull(),
  lastEditedByUserId: int("last_edited_by_user_id"),
  version: int("version").default(1).notNull(),
  parentReportId: int("parent_report_id"), // for versioning
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
  finalizedAt: timestamp("finalized_at"),
  sentAt: timestamp("sent_at"),
});

export type ImpactReport = typeof impactReports.$inferSelect;
export type InsertImpactReport = typeof impactReports.$inferInsert;

/**
 * Report Templates
 * Reusable templates for impact reports
 */
export const reportTemplates = mysqlTable("report_templates", {
  id: int("id").autoincrement().primaryKey(),
  templateName: varchar("template_name", { length: 255 }).notNull(),
  templateType: varchar("template_type", { length: 100 }).notNull(),
  description: text("description"),
  structure: text("structure"), // JSON defining report structure
  defaultSections: text("default_sections"), // JSON array of sections
  isPublic: boolean("is_public").default(false),
  createdByUserId: int("created_by_user_id"),
  language: mysqlEnum("language", ["en", "es", "ca", "eu"]).default("en").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type ReportTemplate = typeof reportTemplates.$inferSelect;
export type InsertReportTemplate = typeof reportTemplates.$inferInsert;

/**
 * Beneficiaries/Participants
 * Track people served by the organization
 */
export const beneficiaries = mysqlTable("beneficiaries", {
  id: int("id").autoincrement().primaryKey(),
  applicationId: int("application_id"), // null for organization-wide
  activityId: int("activity_id"), // null if not activity-specific
  firstName: varchar("first_name", { length: 255 }),
  lastName: varchar("last_name", { length: 255 }),
  isAnonymized: boolean("is_anonymized").default(false),
  anonymizedId: varchar("anonymized_id", { length: 100 }), // for privacy
  age: int("age"),
  gender: varchar("gender", { length: 50 }),
  location: varchar("location", { length: 255 }),
  category: varchar("category", { length: 100 }), // youth, elderly, women, etc.
  participationDate: timestamp("participation_date"),
  participationStatus: mysqlEnum("participation_status", ["active", "completed", "dropped"]).default("active"),
  notes: text("notes"),
  consentGiven: boolean("consent_given").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type Beneficiary = typeof beneficiaries.$inferSelect;
export type InsertBeneficiary = typeof beneficiaries.$inferInsert;

/**
 * Impact Stories Library
 * Reusable impact stories for reports
 */
export const impactStories = mysqlTable("impact_stories", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 500 }).notNull(),
  description: text("description").notNull(),
  beneficiaryType: varchar("beneficiary_type", { length: 255 }), // youth, women, families, etc.
  location: varchar("location", { length: 255 }),
  impact: text("impact"), // measurable impact achieved
  metrics: text("metrics"), // key metrics/numbers
  language: mysqlEnum("language", ["en", "es", "ca", "eu"]).default("en").notNull(),
  tags: text("tags"), // JSON array of tags for filtering
  applicationId: int("application_id"), // optional link to specific application
  createdByUserId: int("created_by_user_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type ImpactStory = typeof impactStories.$inferSelect;
export type InsertImpactStory = typeof impactStories.$inferInsert;

/**
 * Report Documents
 * Documents uploaded for AI analysis and report generation
 */
export const reportDocuments = mysqlTable("report_documents", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("user_id").notNull(),
  fileName: varchar("file_name", { length: 500 }).notNull(),
  fileKey: varchar("file_key", { length: 500 }).notNull(), // S3 key
  fileUrl: text("file_url").notNull(), // S3 URL
  fileType: varchar("file_type", { length: 100 }).notNull(), // pdf, docx, xlsx, jpg, png
  fileSize: int("file_size").notNull(), // in bytes
  mimeType: varchar("mime_type", { length: 100 }).notNull(),
  analysisStatus: mysqlEnum("analysis_status", ["pending", "processing", "completed", "failed"]).default("pending").notNull(),
  analysisResult: text("analysis_result"), // JSON with extracted data
  extractedMetrics: text("extracted_metrics"), // JSON array of metrics
  extractedStories: text("extracted_stories"), // JSON array of potential stories
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  analyzedAt: timestamp("analyzed_at"),
});

export type ReportDocument = typeof reportDocuments.$inferSelect;
export type InsertReportDocument = typeof reportDocuments.$inferInsert;
