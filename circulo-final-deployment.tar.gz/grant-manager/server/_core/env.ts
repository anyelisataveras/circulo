/**
 * Environment configuration with validation
 * 
 * This file ensures all required environment variables are set before
 * the application starts, preventing runtime errors from missing configuration.
 */

/**
 * Required environment variables that must be set
 */
const REQUIRED_ENV_VARS = [
  'VITE_APP_ID',
  'JWT_SECRET',
  'DATABASE_URL',
  'OAUTH_SERVER_URL',
] as const;

/**
 * Optional environment variables with their defaults
 */
const OPTIONAL_ENV_VARS = {
  PORT: '3000',
  NODE_ENV: 'development',
} as const;

/**
 * Validate that a required environment variable is set and non-empty
 */
function requireEnvVar(name: string): string {
  const value = process.env[name];
  
  if (!value || value.trim() === '') {
    throw new Error(
      `FATAL: Required environment variable '${name}' is not set. ` +
      `Please set it in your .env file or environment configuration.`
    );
  }
  
  return value.trim();
}

/**
 * Get optional environment variable with default
 */
function getEnvVar(name: string, defaultValue: string): string {
  const value = process.env[name];
  return value && value.trim() !== '' ? value.trim() : defaultValue;
}

/**
 * Validate JWT secret meets minimum security requirements
 */
function validateJwtSecret(secret: string): void {
  const MIN_SECRET_LENGTH = 32;
  
  if (secret.length < MIN_SECRET_LENGTH) {
    throw new Error(
      `FATAL: JWT_SECRET must be at least ${MIN_SECRET_LENGTH} characters long. ` +
      `Current length: ${secret.length}. ` +
      `Generate a strong secret with: openssl rand -base64 32`
    );
  }
  
  // Warn if secret looks like a placeholder
  const PLACEHOLDER_PATTERNS = [
    /^your[-_]?secret/i,
    /^change[-_]?me/i,
    /^secret$/i,
    /^password$/i,
    /^123/,
  ];
  
  for (const pattern of PLACEHOLDER_PATTERNS) {
    if (pattern.test(secret)) {
      console.warn(
        `⚠️  WARNING: JWT_SECRET appears to be a placeholder value. ` +
        `Please use a cryptographically secure random string in production.`
      );
      break;
    }
  }
}

/**
 * Validate database URL format
 */
function validateDatabaseUrl(url: string): void {
  try {
    const parsed = new URL(url);
    
    if (!['mysql:', 'postgresql:', 'postgres:'].includes(parsed.protocol)) {
      console.warn(
        `⚠️  WARNING: Database URL protocol '${parsed.protocol}' may not be supported. ` +
        `Expected mysql:, postgresql:, or postgres:`
      );
    }
    
    if (!parsed.hostname) {
      throw new Error('Database URL must include a hostname');
    }
  } catch (error) {
    throw new Error(
      `FATAL: DATABASE_URL is not a valid URL format. ` +
      `Error: ${error instanceof Error ? error.message : String(error)}`
    );
  }
}

/**
 * Initialize and validate environment configuration
 */
function initializeEnv() {
  console.log('🔍 Validating environment configuration...');
  
  try {
    // Validate all required environment variables
    const appId = requireEnvVar('VITE_APP_ID');
    const cookieSecret = requireEnvVar('JWT_SECRET');
    const databaseUrl = requireEnvVar('DATABASE_URL');
    const oAuthServerUrl = requireEnvVar('OAUTH_SERVER_URL');
    
    // Validate JWT secret strength
    validateJwtSecret(cookieSecret);
    
    // Validate database URL format
    validateDatabaseUrl(databaseUrl);
    
    // Get optional variables
    const port = getEnvVar('PORT', OPTIONAL_ENV_VARS.PORT);
    const nodeEnv = getEnvVar('NODE_ENV', OPTIONAL_ENV_VARS.NODE_ENV);
    
    // Optional variables that may not be set
    const ownerOpenId = process.env.OWNER_OPEN_ID || '';
    const forgeApiUrl = process.env.BUILT_IN_FORGE_API_URL || '';
    const forgeApiKey = process.env.BUILT_IN_FORGE_API_KEY || '';
    
    // Warn if Forge API is partially configured
    if ((forgeApiUrl && !forgeApiKey) || (!forgeApiUrl && forgeApiKey)) {
      console.warn(
        '⚠️  WARNING: Forge API is partially configured. ' +
        'Both BUILT_IN_FORGE_API_URL and BUILT_IN_FORGE_API_KEY must be set.'
      );
    }
    
    const isProduction = nodeEnv === 'production';
    
    // Production-specific validations
    if (isProduction) {
      if (port === '3000') {
        console.warn('⚠️  WARNING: Running on default port 3000 in production');
      }
      
      if (databaseUrl.includes('localhost') || databaseUrl.includes('127.0.0.1')) {
        console.warn('⚠️  WARNING: Database URL points to localhost in production');
      }
      
      if (!oAuthServerUrl.startsWith('https://')) {
        throw new Error(
          'FATAL: OAUTH_SERVER_URL must use HTTPS in production. ' +
          `Current value: ${oAuthServerUrl}`
        );
      }
    }
    
    console.log('✅ Environment configuration validated successfully');
    
    return {
      appId,
      cookieSecret,
      databaseUrl,
      oAuthServerUrl,
      ownerOpenId,
      forgeApiUrl,
      forgeApiKey,
      port: parseInt(port, 10),
      isProduction,
      isDevelopment: nodeEnv === 'development',
      nodeEnv,
    };
  } catch (error) {
    console.error('\n❌ ENVIRONMENT CONFIGURATION ERROR\n');
    console.error(error instanceof Error ? error.message : String(error));
    console.error('\nThe application cannot start with missing or invalid environment variables.');
    console.error('Please check your .env file or environment configuration.\n');
    
    // Exit the process - don't allow the app to start with invalid config
    process.exit(1);
  }
}

// Initialize and export validated environment
export const ENV = initializeEnv();

/**
 * Helper function to check if a feature flag is enabled
 */
export function isFeatureEnabled(featureName: string): boolean {
  const envVar = `FEATURE_${featureName.toUpperCase()}`;
  const value = process.env[envVar];
  return value === 'true' || value === '1';
}
