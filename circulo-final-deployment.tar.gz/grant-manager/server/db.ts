import { eq, and, desc, gte, lte, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, 
  users,
  grantOpportunities,
  applications,
  projects,
  budgetItems,
  partners,
  documents,
  activities,
  expenses,
  reports,
  auditRecords,
  notifications,
  apiCredentials,
  auditLogs,
  translations,
  googleDriveFiles,
  whatsappMessages,
  emailLogs,
  aiAssistanceSessions,
  n8nWebhooks,
  type GrantOpportunity,
  type Application,
  type Document,
  type WhatsappMessage,
  type EmailLog,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }
    if (user.preferredLanguage !== undefined) {
      values.preferredLanguage = user.preferredLanguage;
      updateSet.preferredLanguage = user.preferredLanguage;
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateUserLanguage(userId: number, language: "en" | "es" | "ca" | "eu") {
  const db = await getDb();
  if (!db) return false;

  await db.update(users).set({ preferredLanguage: language }).where(eq(users.id, userId));
  return true;
}

export async function updateUserGoogleTokens(
  userId: number,
  googleId: string,
  accessToken: string,
  refreshToken: string | null,
  expiryDate: Date | null
) {
  const db = await getDb();
  if (!db) return false;

  await db.update(users).set({
    googleId,
    googleAccessToken: accessToken,
    googleRefreshToken: refreshToken,
    googleTokenExpiry: expiryDate,
  }).where(eq(users.id, userId));
  
  return true;
}

export async function clearUserGoogleTokens(userId: number) {
  const db = await getDb();
  if (!db) return false;

  await db.update(users).set({
    googleId: null,
    googleAccessToken: null,
    googleRefreshToken: null,
    googleTokenExpiry: null,
  }).where(eq(users.id, userId));
  
  return true;
}

// Grant Opportunities
export async function getGrantOpportunities(filters?: {
  status?: string;
  assignedToUserId?: number;
  limit?: number;
}) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select().from(grantOpportunities);
  
  const conditions = [];
  if (filters?.status) {
    conditions.push(eq(grantOpportunities.status, filters.status as any));
  }
  if (filters?.assignedToUserId) {
    conditions.push(eq(grantOpportunities.assignedToUserId, filters.assignedToUserId));
  }

  if (conditions.length > 0) {
    query = query.where(and(...conditions)) as any;
  }

  query = query.orderBy(desc(grantOpportunities.applicationDeadline)) as any;

  if (filters?.limit) {
    query = query.limit(filters.limit) as any;
  }

  return await query;
}

export async function getUpcomingDeadlines(daysAhead: number = 30) {
  const db = await getDb();
  if (!db) return [];

  const now = new Date();
  const futureDate = new Date();
  futureDate.setDate(futureDate.getDate() + daysAhead);

  return await db
    .select()
    .from(grantOpportunities)
    .where(
      and(
        gte(grantOpportunities.applicationDeadline, now),
        lte(grantOpportunities.applicationDeadline, futureDate)
      )
    )
    .orderBy(grantOpportunities.applicationDeadline);
}

// Applications
export async function getApplications(filters?: {
  status?: string;
  assignedToUserId?: number;
  grantOpportunityId?: number;
}) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select().from(applications);
  
  const conditions = [];
  if (filters?.status) {
    conditions.push(eq(applications.status, filters.status as any));
  }
  if (filters?.assignedToUserId) {
    conditions.push(eq(applications.assignedToUserId, filters.assignedToUserId));
  }
  if (filters?.grantOpportunityId) {
    conditions.push(eq(applications.grantOpportunityId, filters.grantOpportunityId));
  }

  if (conditions.length > 0) {
    query = query.where(and(...conditions)) as any;
  }

  query = query.orderBy(desc(applications.createdAt)) as any;

  return await query;
}

export async function getApplicationById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(applications).where(eq(applications.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Documents
export async function getDocuments(filters?: {
  applicationId?: number | null;
  documentType?: string;
}) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select().from(documents);
  
  const conditions = [];
  if (filters?.applicationId !== undefined) {
    if (filters.applicationId === null) {
      conditions.push(sql`${documents.applicationId} IS NULL`);
    } else {
      conditions.push(eq(documents.applicationId, filters.applicationId));
    }
  }
  if (filters?.documentType) {
    conditions.push(eq(documents.documentType, filters.documentType));
  }

  if (conditions.length > 0) {
    query = query.where(and(...conditions)) as any;
  }

  query = query.orderBy(desc(documents.createdAt)) as any;

  return await query;
}

export async function getExpiringDocuments(daysAhead: number = 30) {
  const db = await getDb();
  if (!db) return [];

  const now = new Date();
  const futureDate = new Date();
  futureDate.setDate(futureDate.getDate() + daysAhead);

  return await db
    .select()
    .from(documents)
    .where(
      and(
        sql`${documents.expirationDate} IS NOT NULL`,
        gte(documents.expirationDate, now),
        lte(documents.expirationDate, futureDate)
      )
    )
    .orderBy(documents.expirationDate);
}

// WhatsApp Messages
export async function getWhatsappMessages(filters?: {
  userId?: number;
  applicationId?: number;
  isProcessed?: boolean;
  limit?: number;
}) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select().from(whatsappMessages);
  
  const conditions = [];
  if (filters?.userId) {
    conditions.push(eq(whatsappMessages.userId, filters.userId));
  }
  if (filters?.applicationId) {
    conditions.push(eq(whatsappMessages.applicationId, filters.applicationId));
  }
  if (filters?.isProcessed !== undefined) {
    conditions.push(eq(whatsappMessages.isProcessed, filters.isProcessed));
  }

  if (conditions.length > 0) {
    query = query.where(and(...conditions)) as any;
  }

  query = query.orderBy(desc(whatsappMessages.receivedAt)) as any;

  if (filters?.limit) {
    query = query.limit(filters.limit) as any;
  }

  return await query;
}

// Email Logs
export async function getEmailLogs(filters?: {
  userId?: number;
  status?: string;
  limit?: number;
}) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select().from(emailLogs);
  
  const conditions = [];
  if (filters?.userId) {
    conditions.push(eq(emailLogs.userId, filters.userId));
  }
  if (filters?.status) {
    conditions.push(eq(emailLogs.status, filters.status as any));
  }

  if (conditions.length > 0) {
    query = query.where(and(...conditions)) as any;
  }

  query = query.orderBy(desc(emailLogs.createdAt)) as any;

  if (filters?.limit) {
    query = query.limit(filters.limit) as any;
  }

  return await query;
}

// Audit Logs
export async function createAuditLog(log: {
  userId?: number;
  action: string;
  entityType?: string;
  entityId?: number;
  ipAddress?: string;
  userAgent?: string;
  metadata?: any;
  status: "success" | "failure" | "error";
  errorMessage?: string;
}) {
  const db = await getDb();
  if (!db) return;

  await db.insert(auditLogs).values({
    ...log,
    metadata: log.metadata ? JSON.stringify(log.metadata) : null,
  });
}

// Notifications
export async function getUserNotifications(userId: number, limit: number = 50) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, userId))
    .orderBy(desc(notifications.createdAt))
    .limit(limit);
}

export async function markNotificationAsRead(notificationId: number) {
  const db = await getDb();
  if (!db) return false;

  await db.update(notifications).set({ isRead: true }).where(eq(notifications.id, notificationId));
  return true;
}
